﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SApp03
{
    class ConvertFIle
    {
        private string fileName;
        private string dirName;
        private List<Student> list;

        public string FileName
        {
            set { fileName = value; }
        }
        public string DirName
        {
            set { dirName = value; }
        }

        public ConvertFIle(string fileName, string dirName)
        {
            this.fileName = fileName;
            this.dirName = dirName;
            list = new List<Student>();
        }

        public void LoadXML()
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Student>));
            using (var stream = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                list = (List<Student>)xmlSerializer.Deserialize(stream);
            }
        }
        public void LoadCSV()
        {
            using (StreamReader sr = new StreamReader(fileName, Encoding.GetEncoding(1251)))
            {
                while (!sr.EndOfStream)
                {
                    try
                    {
                        string[] s = sr.ReadLine().Split(';');
                        list.Add(new Student(s));
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                }
            }
        }
        public void SaveXML()
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Student>));
            using (var stream = new FileStream(dirName + "\\Students.xml", FileMode.Create, FileAccess.Write))
            {
                xmlSerializer.Serialize(stream, list);
            }
        }
        public void SaveCSV()
        {
            using (StreamWriter sw = new StreamWriter(dirName + "\\Students.csv", false,Encoding.GetEncoding(1251)))
            {
                foreach(var s in list)
                    sw.WriteLine($"{s.LastName};{s.FirstName};{s.University};{s.Faculty};{s.Department};{s.Age};{s.Course};{s.Group};{s.City}");
            }
        }
    }
}
