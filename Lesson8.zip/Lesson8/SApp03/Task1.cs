﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SApp03
{/*Задание: 1. а) Создать приложение, показанное на уроке, добавив в него защиту от возможных ошибок
               (не создана база данных, обращение к несуществующему вопросу, открытие слишком большого файла и т.д.).
               б) Изменить интерфейс программы, увеличив шрифт, поменяв цвет элементов и добавив другие «косметические»
               улучшения на свое усмотрение.
               в) Добавить в приложение меню «О программе» с информацией о программе (автор, версия,авторские права и др.).
               г) Добавить в приложение сообщение с предупреждением при попытке удалить вопрос.
               д) Добавить пункт меню Save As, в котором можно выбрать имя для сохранения базы данных (элемент SaveFileDialog).

   Фамилия: Орлов
  */
    public partial class Task1 : Form
    {
        private TrueFalse database;
        
        public Task1()
        {
            InitializeComponent();
            lblresult.Text = "";
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void miNew_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.DefaultExt = ".xml";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                database = new TrueFalse(saveFileDialog.FileName);
                nudNumber.Minimum = 0;
                nudNumber.Maximum = 0;
                nudNumber.Value = 0;
                lblresult.Text = "Файл создан";
            }
        }
        private void miOpen_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.DefaultExt = ".xml";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    if (new FileInfo(openFileDialog.FileName).Length > 104857600) // взял размер файла не больше 100 мб
                        MessageBox.Show(this, $"Слишком большой файл!Размер не должен превышать 100 МБ", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                    {
                        database = new TrueFalse(openFileDialog.FileName);
                        database.Load();
                        nudNumber.Minimum = 0;
                        nudNumber.Maximum = database.Count;
                        nudNumber.Value = 0;
                        lblresult.Text = "Файл открыт";

                        if (database.Count != 0)
                        {
                            tbQuestion.Text = database[0].Text;
                            cbTrueFalse.Checked = database[0].TrueFalse;
                            nudNumber.Value = 1;
                        }
                    }
                }
            }
            catch(SystemException ex)
            {
                MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                database = null;
            }
        }
        private void miSave_Click(object sender, EventArgs e)
        {
            if (database != null)
            {
                database.Save();
                lblresult.Text = "Файл сохранён";
            }
            else MessageBox.Show(this, $"Создайте БД!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void miSaveAs_Click(object sender, EventArgs e)
        {
            if (database != null)
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.DefaultExt = ".xml";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    database.Save(saveFileDialog.FileName);
                lblresult.Text = "Файл сохранён";
            }
            else MessageBox.Show(this, $"Создайте БД!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (database == null)
            {
                MessageBox.Show(this, $"Создайте БД!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            database.Add(tbQuestion.Text, cbTrueFalse.Checked);
            nudNumber.Maximum = database.Count;
            nudNumber.Value = database.Count;
            lblresult.Text = "Вопрос добавлен в список";
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (nudNumber.Maximum == 0 || database == null)
            {
                MessageBox.Show(this, $"Создайте БД!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (MessageBox.Show(this, $"Вы точно хотите удалить данный вопрос?", "Предупреждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                database.Remove((int)nudNumber.Value);
                nudNumber.Maximum--;
                if (nudNumber.Value > 1) nudNumber.Value = 1;
                lblresult.Text = "Вопрос удалён из списка";
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (database == null)
            {
                MessageBox.Show(this, $"Нет БД для сохранения!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            database[(int)nudNumber.Value - 1].Text = tbQuestion.Text;
            database[(int)nudNumber.Value - 1].TrueFalse = cbTrueFalse.Checked;
            lblresult.Text = "Локальные изменения сохранены";
        }
        private void nudNumber_ValueChanged(object sender, EventArgs e)
        {
            if (database == null)
            {
                MessageBox.Show(this, $"Создайте БД!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                nudNumber.Value = 0;
                return;
            }
            tbQuestion.Text = database[(int)nudNumber.Value - 1].Text;
            cbTrueFalse.Checked = database[(int)nudNumber.Value - 1].TrueFalse;
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(this, $"Эта программа создана в учебных целях\nАвтор: Михаил Орлов", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
