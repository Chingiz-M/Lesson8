﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SApp03
{
    public partial class Task3 : Form
    {/*Задание: 3. *Написать программу-преобразователь из CSV в XML-файл с информацией о студентах (6 урок). 
      
       Фамилия: Орлов
     */
        ConvertFIle convert;
        public Task3()
        {
            InitializeComponent();
            lblResult.Text = "";
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    if (new FileInfo(openFileDialog.FileName).Length > 104857600) // взял размер файла не больше 100 мб
                        MessageBox.Show(this, $"Слишком большой файл!Размер не должен превышать 100 МБ", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                    {
                        tbInput.Text = openFileDialog.FileName;
                        convert = new ConvertFIle(openFileDialog.FileName, new FileInfo(openFileDialog.FileName).DirectoryName);

                        if (radioButton1.Checked)
                        {
                            convert.LoadCSV();
                            lblResult.Text = "CSV файл открыт";
                        }
                        else
                        {
                            convert.LoadXML();
                            lblResult.Text = "XML файл открыт";
                        }
                    }
                }
            }
            catch (SystemException ex)
            {
                MessageBox.Show(this, ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                convert = null;
            }
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                convert.SaveXML();
                lblResult.Text = "XML файл сохранён";
            }
            else
            {
                convert.SaveCSV();
                lblResult.Text = "CSV файл сохранён";
            }
        }
    }
}
