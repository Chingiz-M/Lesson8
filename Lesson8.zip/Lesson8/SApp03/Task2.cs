﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SApp03
{
    public partial class Task2 : Form
    {/*Задание: 2. Используя полученные знания и класс TrueFalse, разработать игру «Верю — не верю».
                (В файле хранятся вопрос и ответ, правда это или нет. Например: «Шариковую ручку изобрели в древнем Египте», «Да».
                 Компьютер загружает эти данные, случайным образом выбирает 5 вопросов и задаёт их игроку. 
                 Игрок отвечает Да или Нет на каждый вопрос и набирает баллы за каждый правильный ответ.)

       Фамилия: Орлов
     */
        TrueFalse database;
        Random random = new Random();
        int index = -1;
        int num_question = 1;
        int count = 0;
        public Task2()
        {
            InitializeComponent();
            lblQuestion.Text = $"Вопрос {num_question}:";
            lblResult.Text = "";
            database = new TrueFalse(AppDomain.CurrentDomain.BaseDirectory + "Questions.xml");
            database.Load();
            index = random.Next(0, database.Count);
            database[index].Checked = true;
            tbQuestion.Text = database[index].Text;

        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            database[index].Checked = true;
            num_question++;

            if (database[index].TrueFalse)
            {
                lblResult.ForeColor = Color.Green;
                lblResult.Text = "Верно!";
                count++;
            }
            else
            {
                lblResult.ForeColor = Color.Orange;
                lblResult.Text = "Не верно!";
            }
            if (num_question == 6)
            {
                if (MessageBox.Show(this, $"Вы ответили верно на {count} вопросов!\nХотите повторить?", "Вопрос",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    for (int i = 0; i < database.Count; i++)
                        database[i].Checked = false;
                    count = 0;
                    num_question = 1;
                    lblResult.Text = "";
                }
                else
                    Close();
            }
            lblQuestion.Text = $"Вопрос {num_question}:";
            while (true)
            {
                index = random.Next(0, database.Count);
                if (database[index].Checked != true)
                    break;
            }
            tbQuestion.Text = database[index].Text;
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            database[index].Checked = true;
            num_question++;

            if (!database[index].TrueFalse)
            {
                lblResult.ForeColor = Color.Green;
                lblResult.Text = "Верно!";
                count++;
            }
            else
            {
                lblResult.ForeColor = Color.Orange;
                lblResult.Text = "Не верно!";
            }

            if (num_question == 6)
            {
                if (MessageBox.Show(this, $"Вы ответили верно на {count} вопросов!\nХотите повторить?", "Вопрос", 
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    for (int i = 0; i < database.Count; i++)
                        database[i].Checked = false;
                    count = 0;
                    num_question = 1;
                    lblResult.Text = "";
                }
                else
                    Close();
            }
            lblQuestion.Text = $"Вопрос {num_question}:";
            while (true)
            {
                index = random.Next(0, database.Count);
                if (database[index].Checked != true)
                    break;
            }
            tbQuestion.Text = database[index].Text;
        }
    }
}
